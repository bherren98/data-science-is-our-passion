README.txt:
	this file!

artist_data_10-06-2019_170541.json:
	the data containing artists and their gender

artistGenderData.csv:
	the csv file containing the artists and their genders

Billboard-Year-End-Data_with_Fixed_Genres_10-07-2019_011154.json:
	the data containing artists, songs, ranks, and year

GenderDataP2.py:
	The code for conglomerating the data for artists and gender. Also where found mode for categorical data sets

genre_correlation_11-08-2019_121532.csv:
	the correlation data between tags and genre

HypothesisTesting.py:
	The hypothesis testing code for the genre correlation data

